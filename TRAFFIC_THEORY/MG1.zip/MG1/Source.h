// Source.h

#ifndef __SPTFSCHEDULING_SOURCE_H_
#define __SPTFSCHEDULING_SOURCE_H_

#include <omnetpp.h>
#include <ModifiedMessage_m.h>

using namespace omnetpp;

class Source : public cSimpleModule
{
    public:
        Source();
        virtual ~Source();
    private:
        cMessage *sendMessageEvent;
        int nbGenMessages; // msg counter
        double avgInterArrivalTime; // inter arrival time

    protected:
        virtual void initialize();
        virtual void handleMessage(cMessage *msg);
};

#endif
