// MG1.h
#ifndef __SPTFSCHEDULING_MG1_H_
#define __SPTFSCHEDULING_MG1_H_

#include <omnetpp.h>
#include <ModifiedMessage_m.h>
#include <random>
#include <vector>

using namespace omnetpp;

class MG1 : public cSimpleModule
{
    private:
        ModifiedMessage *msgInServer; //message from source that now is in the server
        cMessage *endOfServiceMsg; // event that tells the end of the service

        double L; // maximum value of the uniform distribution

        int nbIntervals; // number of intervals

        simsignal_t queueLengthSignal;
        simsignal_t generalQueuingTimeSignal;
        std::vector<simsignal_t> conditionalQueuingTimeSignals; // it will have nbIntervals elements
        simsignal_t utilizationFactorSignal;
        simsignal_t responseTimeSignal;

        cQueue queue; // list of packets in the queue

        // variables for UtilizactionFactor statistic
        simtime_t startTimeForRho; // used to compute utilization factor values, store the time at which the server becomes busy
        simtime_t totalActiveServerTime; // used to compute utilization factor values, store the total time the server is active (busy)

    public:
        MG1();
        virtual ~MG1();

    protected:
        static int compareFunc(cObject *a, cObject *b);
        virtual void initialize() override;
        virtual void handleMessage(cMessage *msg) override;
        void startPacketService();
        void putPacketInQueue(ModifiedMessage *msg);
};

#endif
